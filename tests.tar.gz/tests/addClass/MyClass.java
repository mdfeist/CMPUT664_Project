class MyClass {
	
}