class NewClass {
	
}