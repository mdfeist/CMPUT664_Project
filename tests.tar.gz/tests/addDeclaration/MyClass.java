class MyClass {
	private Type type = new Type();
}