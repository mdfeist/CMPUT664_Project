class NewClass {
	private Type2 type2 = new Type2();
}