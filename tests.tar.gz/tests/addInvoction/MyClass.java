class MyClass {
	private Type type = new Type();

	public void foo() {
		type.method();
	}
}