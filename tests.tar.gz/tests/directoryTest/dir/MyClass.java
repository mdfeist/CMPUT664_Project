class MyClass {

}
