class MyClass {
	private Type2 type = new Type2();
}