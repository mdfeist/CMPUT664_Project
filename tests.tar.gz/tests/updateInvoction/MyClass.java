class MyClass {
	private Type t1 = new Type();
	private Type t2 = new Type();

	void foo() {
		t2.set();
	}
}
